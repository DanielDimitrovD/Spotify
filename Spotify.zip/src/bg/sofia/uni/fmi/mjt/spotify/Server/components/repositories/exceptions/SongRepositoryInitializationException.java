package bg.sofia.uni.fmi.mjt.spotify.Server.components.repositories.exceptions;

public class SongRepositoryInitializationException extends RuntimeException {
    public SongRepositoryInitializationException(String msg) {
        super(msg);
    }
}
