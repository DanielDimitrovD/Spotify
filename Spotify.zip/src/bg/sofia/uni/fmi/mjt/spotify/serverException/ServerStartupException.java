package bg.sofia.uni.fmi.mjt.spotify.serverException;

public class ServerStartupException extends RuntimeException{
    public ServerStartupException(String message) {
        super(message);
    }
}
